#!/usr/bin/env python3
"""
Simple MJPEG streaming server for Raspberry Pi Camera
Uses picamera2 to stream to port 9000
"""

import io
import time
import logging
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Condition
from picamera2 import Picamera2
from picamera2.encoders import MJPEGEncoder
from picamera2.outputs import FileOutput

# Configuration - Reduce size if better performance is needed ;)
PORT = 9000
WIDTH = 960
HEIGHT = 540

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StreamingOutput(io.BufferedIOBase):
    def __init__(self):
        self.frame = None
        self.condition = Condition()

    def write(self, buf):
        with self.condition:
            self.frame = buf
            self.condition.notify_all()

class StreamingHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '/?action=stream':
            self.send_response(200)
            self.send_header('Age', '0')
            self.send_header('Cache-Control', 'no-cache, private')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=FRAME')
            self.end_headers()
            
            try:
                while True:
                    with output.condition:
                        output.condition.wait()
                        frame = output.frame
                    self.wfile.write(b'--FRAME\r\n')
                    self.send_header('Content-Type', 'image/jpeg')
                    self.send_header('Content-Length', str(len(frame)))
                    self.end_headers()
                    self.wfile.write(frame)
                    self.wfile.write(b'\r\n')
            except (BrokenPipeError, ConnectionResetError):
                logger.info('Client disconnected')
            except Exception as e:
                logger.error(f'Streaming error: {e}')
        else:
            self.send_error(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Suppress log messages
        return

if __name__ == '__main__':
    try:
        # Initialize camera
        logger.info("Initializing camera...")
        picam2 = Picamera2()
        
        config = picam2.create_video_configuration(
            main={"size": (WIDTH, HEIGHT)},
            controls={"FrameDurationLimits": (66666, 66666)}  # ~15fps
        )
        picam2.configure(config)
        
        # Setup streaming
        output = StreamingOutput()
        encoder = MJPEGEncoder()
        picam2.start_recording(encoder, FileOutput(output))
        
        # Give camera time to warm up
        time.sleep(2)
        
        # Start HTTP server
        address = ('', PORT)
        server = HTTPServer(address, StreamingHandler)
        logger.info(f"Camera streaming server started on port {PORT}")
        logger.info(f"Access stream at: http://[pi-ip]:{PORT}/?action=stream")
        server.serve_forever()
        
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    except Exception as e:
        logger.error(f"Error: {e}")
    finally:
        try:
            picam2.stop_recording()
            logger.info("Camera streaming stopped")
        except:
            pass
