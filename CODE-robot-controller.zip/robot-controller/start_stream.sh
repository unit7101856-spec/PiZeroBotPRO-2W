#!/bin/bash

# PID file location
PID_FILE="/tmp/camera_stream.pid"

# Kill existing camera stream using PID file
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if ps -p "$OLD_PID" > /dev/null 2>&1; then
        kill "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "$PID_FILE"
fi

# Kill other streaming processes
sudo killall rpicam-vid 2>/dev/null
sudo killall ffmpeg 2>/dev/null
sudo killall mjpg_streamer 2>/dev/null
sudo pkill -f camera_stream.py 2>/dev/null

# Wait a moment
sleep 2

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Try to start the camera stream, retry up to 3 times if it fails
MAX_RETRIES=3
RETRY_DELAY=5

for i in $(seq 1 $MAX_RETRIES); do
    # Start Python camera streamer in background and save PID
    python3 "$SCRIPT_DIR/camera_stream.py" > /tmp/camera_stream.log 2>&1 &
    STREAM_PID=$!
    echo $STREAM_PID > "$PID_FILE"

    # Wait a few seconds and check if it's still running
    sleep $RETRY_DELAY

    if ps -p $STREAM_PID > /dev/null 2>&1; then
        echo "Camera stream started successfully on port 9000 (PID: $STREAM_PID)"
        exit 0
    else
        echo "Camera stream attempt $i failed, retrying in ${RETRY_DELAY}s..."
        rm -f "$PID_FILE"
        sleep $RETRY_DELAY
    fi
done

echo "Camera stream failed to start after $MAX_RETRIES attempts, check /tmp/camera_stream.log"
exit 1