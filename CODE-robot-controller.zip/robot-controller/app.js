var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var exec = require('child_process').exec;
var port = process.env.PORT || 3000;

// Try to load ADC module, but continue if not available
var ads1x15, adc;
var adcAvailable = false;
try {
  ads1x15 = require('node-ads1x15');
  adc = new ads1x15(1);
  adcAvailable = true;
  console.log('ADC module loaded successfully');
} catch (e) {
  console.log('ADC module not available - voltage monitoring disabled');
  console.log('To enable: npm install node-ads1x15');
}

// GPIO setup using pigpio
var Gpio = require('pigpio').Gpio;
var A1 = new Gpio(27, {mode: Gpio.OUTPUT});
var A2 = new Gpio(17, {mode: Gpio.OUTPUT});
var B1 = new Gpio(4, {mode: Gpio.OUTPUT});
var B2 = new Gpio(18, {mode: Gpio.OUTPUT});
var LED = new Gpio(22, {mode: Gpio.OUTPUT});
var EXTRA = new Gpio(23, {mode: Gpio.OUTPUT});

// Explicitly zero all motor outputs on startup to prevent GPIO floating high
A1.pwmWrite(0);
A2.pwmWrite(0);
B1.pwmWrite(0);
B2.pwmWrite(0);
LED.digitalWrite(0);
EXTRA.digitalWrite(0);

// Serve static HTML file
app.get('/', function(req, res){
  res.sendFile(__dirname + '/Touch.html');
  console.log('HTML sent to client');
});

// Proxy camera stream through port 9000 to avoid browser cross-origin blocking
var http_module = require('http');
app.get('/stream', function(req, res) {
  var options = {
    hostname: '127.0.0.1',
    port: 9000,
    path: '/?action=stream',
    method: 'GET'
  };
  var proxyReq = http_module.request(options, function(proxyRes) {
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res, { end: true });
    req.on('close', function() { proxyReq.destroy(); });
  });
  proxyReq.on('error', function(e) {
    console.log('Stream proxy error: ' + e.message);
    if (!res.headersSent) res.status(503).end();
  });
  proxyReq.end();
});

// Start video stream
console.log('Starting video stream...');
exec("bash " + __dirname + "/start_stream.sh", function(error, stdout, stderr){
  if (error) {
    console.log('Stream start error: ' + error);
  } else {
    console.log('Video stream started');
  }
});

// Socket.IO connection handler
io.on('connection', function(socket){
  console.log('A user connected');

  // Heartbeat watchdog - zero motors if client goes silent for 500ms
  var heartbeatTimer = null;
  function resetHeartbeat() {
    if (heartbeatTimer) clearTimeout(heartbeatTimer);
    heartbeatTimer = setTimeout(function() {
      console.log('Heartbeat lost - stopping motors');
      A1.pwmWrite(0);
      A2.pwmWrite(0);
      B1.pwmWrite(0);
      B2.pwmWrite(0);
    }, 500);
  }

  socket.on('heartbeat', function() {
    resetHeartbeat();
  });
  
  // Handle motor control
  socket.on('pos', function (msx, msy) {
    // Clamp values to -255 to 255 range
    msx = Math.min(Math.max(parseInt(msx), -255), 255);
    msy = Math.min(Math.max(parseInt(msy), -255), 255);

    // Control Motor B (left)
    if(msx > 0){
      B1.pwmWrite(msx);
      B2.pwmWrite(0);
    } else {
      B1.pwmWrite(0);
      B2.pwmWrite(Math.abs(msx));
    }

    // Control Motor A (right)
    if(msy > 0){
      A1.pwmWrite(msy);
      A2.pwmWrite(0);
    } else {
      A1.pwmWrite(0);
      A2.pwmWrite(Math.abs(msy));
    }
  });
  
  // Handle headlight toggle
  socket.on('light', function(toggle) {
    LED.digitalWrite(toggle);
    console.log('Headlight:', toggle ? 'ON' : 'OFF');
  });

  // Handle extra output (momentary)
  socket.on('extra', function(toggle) {
    EXTRA.digitalWrite(toggle);
    console.log('Extra output:', toggle ? 'ON' : 'OFF');
  });  
  
  // Handle shutdown command
  socket.on('power', function(toggle) {
    console.log('Shutting down...');
    // Zero all outputs via pigpio first
    A1.pwmWrite(0);
    A2.pwmWrite(0);
    B1.pwmWrite(0);
    B2.pwmWrite(0);
    LED.digitalWrite(0);
    // Use pinctrl to hold GPIO4 low at the OS level BEFORE pigpio releases it,
    // so the pin stays low after Node exits and through the shutdown sequence
    exec("sudo /usr/bin/pinctrl set 4 op dl", function() {
      setTimeout(function() {
        exec("sudo poweroff");
      }, 500);
    });
  });
  
  // Handle disconnect
  socket.on('disconnect', function () {
    console.log('A user disconnected');
    if (heartbeatTimer) clearTimeout(heartbeatTimer);
    // Stop motors on disconnect for safety
    A1.pwmWrite(0);
    A2.pwmWrite(0);
    B1.pwmWrite(0);
    B2.pwmWrite(0);
    EXTRA.digitalWrite(0);
  });

  // Send temperature and voltage data every 5 seconds
  setInterval(function(){ 
    // Get CPU temperature
    exec("cat /sys/class/thermal/thermal_zone0/temp", function(error, stdout, stderr){
      if(error !== null){
         console.log('Temp read error: ' + error);
      } else {
         var temp = parseFloat(stdout)/1000;
         io.emit('temp', temp);
      }
    });
    
    // Read ADC voltage if available
    if(adcAvailable && adc && !adc.busy){
      adc.readADCSingleEnded(0, '4096', '250', function(err, data){
        if(!err){          
          var voltage = 2 * parseFloat(data) / 1000;
          io.emit('volt', voltage);
        }
      });
    } else if (!adcAvailable) {
      // Send 0 to hide voltage display if ADC not available
      io.emit('volt', 0);
    }
  }, 5000);
});

// Start HTTP server
http.listen(port, function(){
  console.log('Server listening on port ' + port);
  console.log('Access the controller at: http://[pi-ip-address]:' + port);
});

// Graceful shutdown
process.on('SIGINT', function() {
  console.log('\nStopping motors and shutting down...');
  A1.pwmWrite(0);
  A2.pwmWrite(0);
  B1.pwmWrite(0);
  B2.pwmWrite(0);
  LED.digitalWrite(0);
  EXTRA.digitalWrite(0);
  process.exit();
});
